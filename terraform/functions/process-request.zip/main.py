"""
Cloud Function: process-request

Pre-processor that sits between GCS upload and Cloud Run.
Triggered by Eventarc when a JSON file lands in /requests/.

User only provides software selection in JSON. The function automatically
detects WHO uploaded the file via GCS Cloud Audit Logs.

Responsibilities:
  1. Auto-detect uploader (name/email) from Cloud Audit Logs
  2. Read the uploaded JSON request (software only)
  3. Log audit metadata to /audit/ in the same bucket
  4. Compute a software fingerprint (hash of enabled software)
  5. Check if an image with that fingerprint already exists
  6. If duplicate → write status, notify user, skip Cloud Run
  7. If new → enrich JSON with requester info, trigger Cloud Run job
"""

import hashlib
import json
import os
from datetime import datetime, timezone

import functions_framework
from google.cloud import compute_v1, logging as cloud_logging, run_v2, storage


PROJECT_ID = os.environ.get("PROJECT_ID")
REGION = os.environ.get("REGION", "us-east4")
BUCKET_NAME = os.environ.get("BUCKET_NAME")
CLOUD_RUN_JOB = os.environ.get("BUILDER_JOB_NAME", "windows-image-builder")


def detect_uploader(bucket_name: str, object_name: str) -> dict:
    """
    Auto-detect who uploaded the file by querying GCS Cloud Audit Logs.
    Returns: { "name": "...", "email": "...", "team": "auto-detected" }
    """
    try:
        logging_client = cloud_logging.Client(project=PROJECT_ID)

        # Query audit logs for this specific GCS object creation
        filter_str = (
            f'resource.type="gcs_bucket" '
            f'resource.labels.bucket_name="{bucket_name}" '
            f'protoPayload.methodName="storage.objects.create" '
            f'protoPayload.resourceName="projects/_/buckets/{bucket_name}/objects/{object_name}" '
            f'severity="NOTICE" '
            f'timestamp>="{(datetime.now(timezone.utc)).strftime("%Y-%m-%dT%H:%M:%SZ")}"'
        )

        # Look at recent entries (last 5 minutes)
        entries = list(logging_client.list_entries(
            filter_=filter_str,
            order_by=cloud_logging.DESCENDING,
            max_results=5,
        ))

        if entries:
            for entry in entries:
                payload = entry.payload if hasattr(entry, 'payload') else {}
                proto = entry.proto_payload if hasattr(entry, 'proto_payload') else None

                # Try to get the caller identity
                if proto and hasattr(proto, 'authentication_info'):
                    email = proto.authentication_info.principal_email
                    if email:
                        # Extract name from email (part before @)
                        name = email.split("@")[0].replace(".", " ").title()
                        print(f"[DETECT] Uploader detected from audit log: {name} <{email}>")
                        return {"name": name, "email": email, "team": "auto-detected"}

        print("[DETECT] Could not find uploader in audit logs — trying object metadata")

    except Exception as e:
        print(f"[DETECT] Audit log query failed: {e}")

    # Fallback: check GCS object metadata (custom metadata set by uploader)
    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(object_name)
        blob.reload()

        if blob.metadata:
            email = blob.metadata.get("uploaded-by", blob.metadata.get("email", ""))
            name = blob.metadata.get("uploader-name", blob.metadata.get("name", ""))
            if email:
                if not name:
                    name = email.split("@")[0].replace(".", " ").title()
                print(f"[DETECT] Uploader detected from object metadata: {name} <{email}>")
                return {"name": name, "email": email, "team": "auto-detected"}

        # Last fallback: use the object owner
        if blob.owner and "entity" in blob.owner:
            entity = blob.owner["entity"]
            if "user-" in entity:
                email = entity.replace("user-", "")
                name = email.split("@")[0].replace(".", " ").title()
                print(f"[DETECT] Uploader detected from object owner: {name} <{email}>")
                return {"name": name, "email": email, "team": "auto-detected"}

    except Exception as e:
        print(f"[DETECT] Object metadata check failed: {e}")

    print("[DETECT] Could not auto-detect uploader")
    return {"name": "unknown", "email": "unknown", "team": "unknown"}


def compute_software_fingerprint(software: dict) -> str:
    """
    Create a deterministic hash of the enabled software combination.
    Only includes keys with truthy values, sorted alphabetically.
    """
    enabled = sorted(
        k for k, v in software.items()
        if v is True or str(v).lower() in ("true", "1", "yes")
    )
    fingerprint_str = ",".join(enabled)
    return hashlib.sha256(fingerprint_str.encode()).hexdigest()[:16]


def find_existing_image(fingerprint: str) -> dict | None:
    """
    Check if a GCP image with this software fingerprint label exists.
    Returns image info dict if found, None otherwise.
    """
    client = compute_v1.ImagesClient()
    request = compute_v1.ListImagesRequest(
        project=PROJECT_ID,
        filter=f'labels.software-fingerprint="{fingerprint}" AND deprecated.state!="DELETED"',
        max_results=5,
    )

    for image in client.list(request=request):
        if not image.deprecated or image.deprecated.state == "":
            return {
                "name": image.name,
                "family": image.family,
                "creation_timestamp": image.creation_timestamp,
                "self_link": image.self_link,
            }
        if image.deprecated.state == "DEPRECATED":
            return {
                "name": image.name,
                "family": image.family,
                "creation_timestamp": image.creation_timestamp,
                "self_link": image.self_link,
                "status": "DEPRECATED",
            }
    return None


def write_audit_log(bucket_name: str, request_data: dict, fingerprint: str, action: str):
    """
    Write an audit entry to /audit/ in the GCS bucket.
    Every request gets a permanent record regardless of outcome.
    """
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)

    request_id = request_data.get("request_id", "unknown")
    now = datetime.now(timezone.utc).isoformat()

    requester = request_data.get("requester", {})
    software = request_data.get("image_config", {}).get("software", {})
    enabled_software = sorted(
        k for k, v in software.items()
        if v is True or str(v).lower() in ("true", "1", "yes")
    )

    audit_entry = {
        "request_id": request_id,
        "timestamp": now,
        "requester": {
            "name": requester.get("name", "unknown"),
            "email": requester.get("email", "unknown"),
            "team": requester.get("team", "unknown"),
        },
        "software_requested": enabled_software,
        "software_fingerprint": fingerprint,
        "image_config_name": request_data.get("image_config", {}).get("image_name", ""),
        "create_vm": request_data.get("image_config", {}).get("create_vm", False),
        "action": action,
    }

    blob_name = f"audit/{request_id}_{now.replace(':', '-')}.json"
    blob = bucket.blob(blob_name)
    blob.upload_from_string(json.dumps(audit_entry, indent=2), content_type="application/json")
    print(f"[AUDIT] Written to gs://{bucket_name}/{blob_name}")
    return audit_entry


def write_status(bucket_name: str, request_data: dict, status: str, message: str, image_name: str = ""):
    """Write status JSON to /status/ in the bucket."""
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)

    request_id = request_data.get("request_id", "unknown")
    requester = request_data.get("requester", {})
    now = datetime.now(timezone.utc).isoformat()

    status_data = {
        "request_id": request_id,
        "status": status,
        "requester": {
            "name": requester.get("name", "unknown"),
            "email": requester.get("email", "unknown"),
            "team": requester.get("team", "unknown"),
        },
        "requested_at": request_data.get("requested_at", now),
        "updated_at": now,
        "config": {
            "image_family": request_data.get("image_config", {}).get("image_name", ""),
            "project_id": PROJECT_ID,
            "create_vm": request_data.get("image_config", {}).get("create_vm", False),
            "software": request_data.get("image_config", {}).get("software", {}),
        },
        "result": {
            "image_name": image_name,
            "vm_name": "none",
        },
        "message": message,
    }

    blob = bucket.blob(f"status/{request_id}.json")
    blob.upload_from_string(json.dumps(status_data, indent=2), content_type="application/json")
    print(f"[STATUS] {status} → gs://{bucket_name}/status/{request_id}.json")


def trigger_cloud_run_job(request_json_gcs: str):
    """Trigger the Cloud Run job with REQUEST_JSON_GCS override."""
    client = run_v2.JobsClient()

    job_name = f"projects/{PROJECT_ID}/locations/{REGION}/jobs/{CLOUD_RUN_JOB}"

    override = run_v2.RunJobRequest.Overrides(
        container_overrides=[
            run_v2.RunJobRequest.Overrides.ContainerOverride(
                name="windows-packer-builder",
                env=[
                    run_v2.EnvVar(name="REQUEST_JSON_GCS", value=request_json_gcs),
                ],
            )
        ]
    )

    request = run_v2.RunJobRequest(name=job_name, overrides=override)
    operation = client.run_job(request=request)

    print(f"[CLOUD RUN] Triggered job: {CLOUD_RUN_JOB}")
    print(f"[CLOUD RUN] Execution: {operation.metadata}")
    return operation


@functions_framework.cloud_event
def process_request(cloud_event):
    """
    Main entry point. Triggered by Eventarc on GCS object.finalize.
    """
    data = cloud_event.data
    bucket_name = data["bucket"]
    object_name = data["name"]

    # Only process files in the requests/ prefix
    if not object_name.startswith("requests/"):
        print(f"[SKIP] Ignoring non-request file: {object_name}")
        return "Skipped", 200

    if not object_name.endswith(".json"):
        print(f"[SKIP] Ignoring non-JSON file: {object_name}")
        return "Skipped", 200

    # ── Guard: skip if already processed (prevents recursive trigger) ────
    storage_client_check = storage.Client()
    bucket_check = storage_client_check.bucket(bucket_name)
    blob_check = bucket_check.blob(object_name)
    raw = json.loads(blob_check.download_as_text())
    if raw.get("_processed"):
        print(f"[SKIP] Already processed (recursive trigger blocked): {object_name}")
        return "Already processed", 200

    print(f"[START] Processing request: gs://{bucket_name}/{object_name}")

    # ── 1. Read the JSON request ──────────────────────────────────────────
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(object_name)
    request_data = json.loads(blob.download_as_text())

    # ── 2. Auto-detect who uploaded the file ──────────────────────────────
    # User does NOT need to put name/email in JSON — we detect automatically
    if "requester" not in request_data or not request_data["requester"].get("email"):
        detected = detect_uploader(bucket_name, object_name)
        request_data["requester"] = detected
        print(f"[AUTO-DETECT] Requester: {detected['name']} <{detected['email']}>")
    else:
        print(f"[JSON] Requester provided in JSON: {request_data['requester']}")

    requester = request_data["requester"]
    requester_name = requester.get("name", "unknown")
    requester_email = requester.get("email", "unknown")

    # ── 3. Auto-generate request_id ───────────────────────────────────────
    request_id = request_data.get("request_id", "")
    if not request_id:
        ts = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
        hash_suffix = hashlib.md5(f"{object_name}{requester_email}".encode()).hexdigest()[:6]
        request_id = f"req-{ts}-{hash_suffix}"
        request_data["request_id"] = request_id

    # Set requested_at timestamp
    if "requested_at" not in request_data:
        request_data["requested_at"] = datetime.now(timezone.utc).isoformat()

    software = request_data.get("image_config", {}).get("software", {})
    enabled_software = sorted(
        k for k, v in software.items()
        if v is True or str(v).lower() in ("true", "1", "yes")
    )

    print(f"[REQUEST] ID: {request_id}")
    print(f"[REQUEST] Requester: {requester_name} <{requester_email}>")
    print(f"[REQUEST] Software: {', '.join(enabled_software)}")

    # ── 4. Compute software fingerprint ───────────────────────────────────
    fingerprint = compute_software_fingerprint(software)
    print(f"[FINGERPRINT] {fingerprint} ({', '.join(enabled_software)})")

    # ── 5. Check for existing image with same fingerprint ─────────────────
    existing_image = find_existing_image(fingerprint)

    if existing_image:
        image_name = existing_image["name"]
        image_family = existing_image.get("family", "")
        created_at = existing_image.get("creation_timestamp", "")

        print(f"[DUPLICATE] Image already exists: {image_name} (created: {created_at})")

        # Write audit log
        write_audit_log(bucket_name, request_data, fingerprint, action="DUPLICATE_FOUND")

        # Write status
        message = (
            f"Hi {requester_name}, an image with the exact same software combination "
            f"already exists: '{image_name}' (family: {image_family}). "
            f"No new build is needed. You can use this existing image directly."
        )
        write_status(bucket_name, request_data, "DUPLICATE", message, image_name=image_name)

        return "Duplicate detected — skipped build", 200

    # ── 6. No duplicate — enrich JSON and trigger build ───────────────────
    print(f"[NEW] No existing image with fingerprint {fingerprint} — triggering build")

    # Mark as processed to prevent recursive triggers
    request_data["_processed"] = True

    # Write enriched JSON to /processed/ (not /requests/) for Cloud Run to read
    processed_name = object_name.replace("requests/", "processed/", 1)
    enriched_blob = bucket.blob(processed_name)
    enriched_blob.upload_from_string(
        json.dumps(request_data, indent=2),
        content_type="application/json",
    )
    print(f"[ENRICH] Written enriched JSON to gs://{bucket_name}/{processed_name}")

    # Also mark the original as processed so re-triggers are blocked
    original_blob = bucket.blob(object_name)
    original_data = request_data.copy()
    original_blob.upload_from_string(
        json.dumps(original_data, indent=2),
        content_type="application/json",
    )
    print(f"[ENRICH] Marked original as processed")

    # Write audit log
    write_audit_log(bucket_name, request_data, fingerprint, action="BUILD_TRIGGERED")

    # Write initial status
    write_status(
        bucket_name, request_data, "QUEUED",
        f"Build queued for {requester_name}. Software: {', '.join(enabled_software)}",
    )

    # Trigger Cloud Run job with the enriched JSON path
    request_json_gcs = f"gs://{bucket_name}/{processed_name}"
    trigger_cloud_run_job(request_json_gcs)

    return "Build triggered", 200
